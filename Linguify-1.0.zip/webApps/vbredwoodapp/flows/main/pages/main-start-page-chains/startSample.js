define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class startSample extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const recordedAudio = await $functions.recordSample(context);

      console.log(recordedAudio);

      const uniqueFilename = `audio_${Date.now()}.mp3`;

      const fileWithName = new File([recordedAudio.blob], uniqueFilename, {
        type: recordedAudio.blob.type,
      });

      console.log(fileWithName);
      
      $page.variables.audioFiles.push(fileWithName);

      $page.variables.hasSample = true;
    }
  }

  return startSample;
});
