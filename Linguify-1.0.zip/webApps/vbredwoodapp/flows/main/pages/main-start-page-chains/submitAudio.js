define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class submitAudio extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const audioSample = new FormData();
      for (let i = 0; i < $page.variables.audioFiles.length; i++) {
        audioSample.append('file', $page.variables.audioFiles[i]);
      }
      audioSample.append('userID', $page.variables.username);

      // Log all the files in the FormData
      for (let pair of audioSample.entries()) {
        console.log(pair[0], pair[1]);
      }

      await Actions.callRest(context, {
        endpoint: 'sendSamples/postUpload',
        body: audioSample,
      });

      await Actions.callComponentMethod(context, {
        selector: '#oj-dialog--1896815765-2',
        method: 'close',
      });
      
    }
  }

  return submitAudio;
});
