define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class handleSubmit extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Get the username from the page variable
      var username = $page.variables.username;

      // Save it to sessionStorage
      sessionStorage.setItem('username', username);

      // Alternatively, to use localStorage instead, uncomment the following line:
      // localStorage.setItem('username', username);

      await Actions.callComponentMethod(context, {
        selector: '#oj-dialog--1896815765-1',
        method: 'close',
      });

    }
  }

  return handleSubmit;
});
