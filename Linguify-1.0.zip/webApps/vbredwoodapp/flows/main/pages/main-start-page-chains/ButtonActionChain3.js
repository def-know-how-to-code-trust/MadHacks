define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain3 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;      

      const ojDialog18968157652Open = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog--1896815765-2',
        method: 'open',
      });
    }
  }

  return ButtonActionChain3;
});
