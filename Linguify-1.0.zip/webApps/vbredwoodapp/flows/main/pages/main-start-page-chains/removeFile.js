define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class removeFile extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.fileIndex 
     */
    async run(context, { fileIndex }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      
      if ($page.variables.audioFiles.length > 1) {
        try {
          // Await the removal of the specified audio file
          await $functions.removeAudioFile(fileIndex, context);
          console.log(`Audio file at index ${fileIndex} has been removed.`);
        } catch (error) {
          // Handle any errors that occur during the removal process
          console.error("Error removing audio file:", error);
        }
      } else {
        // If there's one or no audio files, reset the array to empty
        $page.variables.audioFiles = [];
        $page.variables.hasSample = false;
        console.log("audioFiles array has been reset to empty.");
      }
    }
  }

  return removeFile;
});
