define([
    'vb/action/actionChain',
    'vb/action/actions',
    'vb/action/actionUtils',
  ], (
    ActionChain,
    Actions,
    ActionUtils
  ) => {
    'use strict';
  
    class beginRecording extends ActionChain {
      /**
       * @param {Object} context
       * @return {any} 
       */
      async run(context) {
        const { $page } = context;
        
        // Set recording flag to true
        $page.variables.recordFlag = true;

        try {
          // Start recording and get the initial setup result
          const recordingResult = await $page.functions.startRecording(context);
          
          if (!recordingResult.success) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Failed to start recording: ' + recordingResult.message,
              severity: 'error'
            });
            $page.variables.recordFlag = false;
            return;
          }        

          // Success notification
          await Actions.fireNotificationEvent(context, {
            summary: 'Recording started',
            severity: 'confirmation',
            displayMode: 'persist',

          }, { id: 'RecordingStartNotif' });

        } catch (error) {
          console.error('Recording error:', error);
          
          // Reset recording flag
          $page.variables.recordFlag = false;
          
          // Show error notification
          await Actions.fireNotificationEvent(context, {
            summary: 'Error starting recording: ' + (error.message || 'Unknown error'),
            severity: 'error'
          });
        }
      }
    }
  
    return beginRecording;
  });