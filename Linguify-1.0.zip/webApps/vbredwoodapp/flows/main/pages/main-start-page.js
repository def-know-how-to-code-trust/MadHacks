define([
  'vb/action/actions'
], (
  Actions
) => {
  'use strict';

  let mediaRecorder;
  let audioChunks = [];
  let notificationElement = '';
  let currentBlobIndex = 0;

  class PageModule {
    constructor() {
      this.isRecording = false;
      this.isDownloadInProgress = false;
      this.accumulatedTranscript = '';
      this.accumulatedTranslation = '';
      this.recordingStartTime = null;
      this.accumulatedAudioBuffers = []; // Store decoded audio buffers
      this.originalAudio = [];
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)();

      // Bind methods
      this.handleRecordingStop = this.handleRecordingStop.bind(this);
      this.sendAudioToServer = this.sendAudioToServer.bind(this);
      this.handleApiResponse = this.handleApiResponse.bind(this);
      this.createFormData = this.createFormData.bind(this);
      this.concatenateAudioBuffers = this.concatenateAudioBuffers.bind(this);
      this.recordSample = this.recordSample.bind(this);
      this.updateLocalAudio = this.updateLocalAudio.bind(this);
      this.removeAudioFile = this.removeAudioFile.bind(this);
      this.startRecording = this.startRecording.bind(this);
      this.stopRecording = this.stopRecording.bind(this);
    }

    initializeCodeMirror() {
      console.log('CodeMirror initialization');
    }

    removeAudioFile(index, context) {
      const audioFiles = context.$page.variables.audioFiles;
      if (index > -1) {
        audioFiles.splice(index, 1);
        context.$page.variables.audioFiles = audioFiles;
      }
    }

    async updateLocalAudio() {
      const localAudioElement = document.getElementById('audio--1896815765-1');
      if (localAudioElement) {
        // Clean up old URL if it exists
        if (this.localAudioUrl) {
          URL.revokeObjectURL(this.localAudioUrl);
        }
      }
    }

    async playMergedAudio() {
      if (this.originalAudio.length === 0) {
        console.log("No audio blobs to play.");
        return;
      }

      // Concatenate all blobs into one
      const mergedBlob = new Blob(this.originalAudio, { type: 'audio/wav' });

      // Revoke previous URL if it exists to free memory
      if (this.mergedBlobURL) {
        URL.revokeObjectURL(this.mergedBlobURL);
      }

      // Create a new URL for the merged blob
      this.mergedBlobURL = URL.createObjectURL(mergedBlob);
      console.log("Merged Blob URL:", this.mergedBlobURL);

      const localAudioElement = document.getElementById('audio--1896815765-1');

      if (localAudioElement) {
        localAudioElement.src = this.mergedBlobURL;
        localAudioElement.load();

        localAudioElement.onended = () => {
          console.log("Merged audio has been played.");
          URL.revokeObjectURL(this.mergedBlobURL);
          this.mergedBlobURL = null;
        };

        try {
          await localAudioElement.play();
        } catch (error) {
          console.error("Error playing merged audio:", error);
          this.isPlaying = false;
        }
      } else {
        console.error("Audio element with ID 'audio--1896815765-1' not found.");
      }
    }

    async storeAndQueueAudio(audioBlob) {
      this.originalAudio.push(audioBlob);
      this.playMergedAudio();
    }

    async concatenateAudioBuffers(newBuffer) {
      this.accumulatedAudioBuffers.push(newBuffer);

      // Get total length of all buffers
      const totalLength = this.accumulatedAudioBuffers.reduce(
        (length, buffer) => length + buffer.length,
        0
      );

      // Create new buffer with combined length
      const concatenated = this.audioContext.createBuffer(
        newBuffer.numberOfChannels,
        totalLength,
        newBuffer.sampleRate
      );

      // Copy data from each buffer
      let offset = 0;
      for (const buffer of this.accumulatedAudioBuffers) {
        for (let channel = 0; channel < buffer.numberOfChannels; channel++) {
          concatenated.getChannelData(channel).set(buffer.getChannelData(channel), offset);
        }
        offset += buffer.length;
      }

      return concatenated;
    }

    async base64ToAudioBuffer(base64) {
      // Decode base64 to binary
      const binaryString = atob(base64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Create a Blob from the bytes
      const audioBlob = new Blob([bytes], { type: 'audio/wav' });

      // Convert Blob to ArrayBuffer
      const arrayBuffer = await audioBlob.arrayBuffer();

      // Decode the audio data
      const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);
      return audioBuffer;
    }

    async audioBufferToWav(audioBuffer) {
      const wavData = this.encodeWAV(audioBuffer);
      const wavBlob = new Blob([wavData], { type: 'audio/mp3' });
      return wavBlob;
    }

    encodeWAV(audioBuffer) {
      const numChannels = audioBuffer.numberOfChannels;
      const sampleRate = audioBuffer.sampleRate;
      const format = 1; // PCM
      const bitDepth = 16;

      let result;
      if (numChannels === 2) {
        result = this.interleave(audioBuffer.getChannelData(0), audioBuffer.getChannelData(1));
      } else {
        result = audioBuffer.getChannelData(0);
      }

      const bytesPerSample = bitDepth / 8;
      const blockAlign = numChannels * bytesPerSample;
      const byteRate = sampleRate * blockAlign;
      const dataSize = result.length * bytesPerSample;
      const buffer = new ArrayBuffer(44 + dataSize);
      const view = new DataView(buffer);

      /* RIFF identifier */
      this.writeString(view, 0, 'RIFF');
      /* file length */
      view.setUint32(4, 36 + dataSize, true);
      /* RIFF type */
      this.writeString(view, 8, 'WAVE');
      /* format chunk identifier */
      this.writeString(view, 12, 'fmt ');
      /* format chunk length */
      view.setUint32(16, 16, true);
      /* sample format (raw) */
      view.setUint16(20, format, true);
      /* channel count */
      view.setUint16(22, numChannels, true);
      /* sample rate */
      view.setUint32(24, sampleRate, true);
      /* byte rate (sample rate * block align) */
      view.setUint32(28, byteRate, true);
      /* block align (channel count * bytes per sample) */
      view.setUint16(32, blockAlign, true);
      /* bits per sample */
      view.setUint16(34, bitDepth, true);
      /* data chunk identifier */
      this.writeString(view, 36, 'data');
      /* data chunk length */
      view.setUint32(40, dataSize, true);

      // Write the PCM samples
      let offset = 44;
      for (let i = 0; i < result.length; i++, offset += bytesPerSample) {
        const s = Math.max(-1, Math.min(1, result[i]));
        view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
      }

      return view.buffer;
    }

    interleave(inputL, inputR) {
      const length = inputL.length + inputR.length;
      const result = new Float32Array(length);

      let index = 0;
      let inputIndex = 0;

      while (index < length) {
        result[index++] = inputL[inputIndex];
        result[index++] = inputR[inputIndex];
        inputIndex++;
      }
      return result;
    }

    writeString(view, offset, string) {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    }

    async updateAudioPlayback(audioBuffer) {
      try {
        const audioBlob = await this.audioBufferToWav(audioBuffer);
        const audioUrl = URL.createObjectURL(audioBlob);
        const audioElement = document.getElementById('audio-playback');

        if (audioElement) {
          const oldUrl = audioElement.dataset.blobUrl;

          audioElement.src = audioUrl;
          audioElement.dataset.blobUrl = audioUrl;

          audioElement.onloadedmetadata = () => {
            // Optionally, start playback automatically
            // audioElement.play();
          };

          if (oldUrl) {
            URL.revokeObjectURL(oldUrl);
          }
        }
      } catch (error) {
        console.error('Error updating audio playback:', error);
      }
    }

    startRecording(context) {
      console.log("startRecording called");
      return new Promise((resolve, reject) => {
        navigator.mediaDevices.getUserMedia({ audio: true })
          .then(stream => {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const source = this.audioContext.createMediaStreamSource(stream);
            const processor = this.audioContext.createScriptProcessor(4096, 1, 1);

            source.connect(processor);
            processor.connect(this.audioContext.destination);

            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const bufferData = new Float32Array(inputData);
              audioChunks.push(bufferData);
            };

            this.stream = stream;
            this.processor = processor;

            this.isRecording = true;
            this.recordingStartTime = Date.now();
            this.recordingContext = context;

            resolve({ success: true });
          })
          .catch(error => {
            console.error('MediaRecorder error:', error);
            reject({ success: false, message: error.message });
          });
      });
    }

    stopRecording() {
      return new Promise((resolve, reject) => {
        if (this.isRecording) {
          // Stop the processor and stream
          this.processor.disconnect();
          this.stream.getTracks().forEach(track => track.stop());
          this.isRecording = false;

          // Handle the recorded audio
          this.handleRecordingStop(this.recordingContext).then(() => {
            resolve({ success: true });
          }).catch(error => {
            reject({ success: false, message: error.message });
          });
        } else {
          reject({ success: false, message: 'No active recording' });
        }
      });
    }

    async handleRecordingStop(context) {
      try {
        // Convert the recorded Float32Array chunks to a single Float32Array
        const flatData = this.flattenArray(audioChunks);

        // Create an AudioBuffer
        const audioBuffer = this.audioContext.createBuffer(1, flatData.length, this.audioContext.sampleRate);
        audioBuffer.copyToChannel(flatData, 0);

        // Convert AudioBuffer to WAV Blob
        const audioBlob = await this.audioBufferToWav(audioBuffer);

        // Save local copy of the recorded audio
        await this.storeAndQueueAudio(audioBlob);

        // Create form data and send audio to server
        const formData = this.createFormData(audioBlob, context);
        await this.sendAudioToServer(formData, context);
        audioChunks = [];
      } catch (error) {
        console.error('Error processing audio:', error);
        if (context.$page) {
          Actions.fireNotificationEvent(context, {
            message: 'Error processing audio: ' + error.message,
            severity: 'error',
            displayMode: 'transient'
          });
        }
      }
    }

    flattenArray(channelBuffer) {
      const length = channelBuffer.reduce((acc, curr) => acc + curr.length, 0);
      const result = new Float32Array(length);
      let offset = 0;
      for (let i = 0; i < channelBuffer.length; i++) {
        result.set(channelBuffer[i], offset);
        offset += channelBuffer[i].length;
      }
      return result;
    }

    async sendAudioToServer(formData, context) {
      try {
        const response = await Actions.callRest(context, {
          endpoint: 'Clone/postAmd',
          body: formData
        });

        return await this.handleApiResponse(response, context);
      } catch (error) {
        console.error('API Error:', error);
        if (context.$page) {
          Actions.fireNotificationEvent(context, {
            message: 'API Error: ' + error.message,
            severity: 'error',
            displayMode: 'transient'
          });
        }
        throw error;
      }
    }

    async handleApiResponse(response, context) {
      try {
        const jsonData = typeof response.body === 'string' ?
          JSON.parse(response.body) : response.body;

        if (jsonData.audio_data) {
          try {
            const newAudioBuffer = await this.base64ToAudioBuffer(jsonData.audio_data);
            const concatenatedBuffer = await this.concatenateAudioBuffers(newAudioBuffer);
            await this.updateAudioPlayback(concatenatedBuffer);
          } catch (error) {
            console.error('Error processing audio:', error);
          }
        }

        if (jsonData.result) {
          this.accumulatedTranscript += (this.accumulatedTranscript ? '\n' : '') + jsonData.result;

          if (context.$page && context.$page.variables) {
            context.$page.variables.transcript = this.accumulatedTranscript;
          }

          const textArea = document.getElementById('code');
          if (textArea) {
            textArea.value = this.accumulatedTranscript;
            textArea.scrollTop = textArea.scrollHeight;
          }
        }

        if (jsonData.translated) {
          this.accumulatedTranslation += (this.accumulatedTranslation ? '\n' : '') + jsonData.translated;

          const translationArea = document.getElementById('translationTxt');
          if (translationArea) {
            translationArea.value = this.accumulatedTranslation;
            translationArea.scrollTop = translationArea.scrollHeight;
          }
        }

        return jsonData;
      } catch (error) {
        console.error('Error handling API response:', error);
        throw error;
      }
    }

    createFormData(audioBlob, context) {
      const formData = new FormData();
      formData.append('file', audioBlob, 'audio.mp3');
      const targetLang = document.getElementById('targetLanguage')?.value || 'en';
      formData.append('targetLang', targetLang);
      formData.append('userID', context.$page.variables.username);
      return formData;
    }

    resetAudioPlayback() {
      const originalElement = document.getElementById("audio--1896815765-1");
      if (originalElement) {
        // Clear the audio source
        originalElement.src = "";
        originalElement.load();

        // Disable the play controls (if you want to manage button state explicitly)
        const playButton = originalElement.querySelector("button"); // Depending on your structure
        if (playButton) {
          playButton.disabled = true; // Disable the play button if needed
        }
      }

      const cloneElement = document.getElementById("audio-playback");
      if (cloneElement) {
        // Clear the audio source
        cloneElement.src = "";
        cloneElement.load();

        const playButton = cloneElement.querySelector("button"); // Depending on your structure
        if (playButton) {
          playButton.disabled = true; // Disable the play button if needed
        }
      }

      const textArea = document.getElementById('code');
      if (textArea) {
        textArea.value = "";
        this.accumulatedTranscript = "";
      }
      const translationArea = document.getElementById('translationTxt');
      if (translationArea) {
        translationArea.value = "";
        this.accumulatedTranslation = "";
      }

      this.accumulatedAudioBuffers = []; // Store decoded audio buffers
      this.originalAudio = [];
    }

    recordSample(context) {
      console.log("recordSample called");
      return new Promise((resolve, reject) => {
        if (this.isRecording) {
          // Prevent multiple recordings at the same time
          reject(new Error('Recording is already in progress.'));
          return;
        }

        this.isRecording = true;

        // Disable the Record button
        if (context.$page && context.$page.variables) {
          context.$page.variables.isRecording = true;
        }

        // Notify the user that recording has started
        Actions.fireNotificationEvent(context, {
          message: 'Recording started. It will last for 1 minute.',
          severity: 'info',
          displayMode: 'transient',
          autoDismiss: 'on'
        });

        // Start recording
        navigator.mediaDevices.getUserMedia({ audio: true })
          .then(stream => {
            const mediaRecorder = new MediaRecorder(stream);
            let audioChunks = [];

            mediaRecorder.ondataavailable = event => {
              if (event.data.size > 0) {
                audioChunks.push(event.data);
              }
            };

            mediaRecorder.onstop = () => {
              const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
              audioChunks = [];

              // Create an audio URL
              const audioURL = URL.createObjectURL(audioBlob);

              // Re-enable the Record button
              this.isRecording = false;
              if (context.$page && context.$page.variables) {
                context.$page.variables.isRecording = false;
                context.$page.variables.timeLeft = null; // Clear the countdown
              }

              // Notify the user that recording has stopped
              Actions.fireNotificationEvent(context, {
                message: 'Recording has stopped.',
                severity: 'info',
                displayMode: 'transient',
                autoDismiss: 'on'
              });

              // Resolve the Promise with the audio file
              resolve({ url: audioURL, blob: audioBlob });
            };

            mediaRecorder.start();

            // Start the countdown timer
            let timeLeft = 60; // in seconds
            if (context.$page && context.$page.variables) {
              context.$page.variables.timeLeft = timeLeft;
            }

            const countdownInterval = setInterval(() => {
              timeLeft--;
              if (context.$page && context.$page.variables) {
                context.$page.variables.timeLeft = timeLeft;
              }

              if (timeLeft <= 0) {
                clearInterval(countdownInterval);
                // Stop recording
                mediaRecorder.stop();
                // Stop all tracks on the stream
                stream.getTracks().forEach(track => track.stop());
              }
            }, 1000);
          })
          .catch(err => {
            console.error('The following error occurred: ', err);
            // Re-enable the button in case of error
            this.isRecording = false;
            if (context.$page && context.$page.variables) {
              context.$page.variables.isRecording = false;
            }

            // Notify the user of the error
            Actions.fireNotificationEvent(context, {
              message: 'Error starting recording: ' + err.message,
              severity: 'error',
              displayMode: 'transient',
              autoDismiss: 'on'
            });

            // Reject the Promise with the error
            reject(err);
          });
      });
    }
  }

  return PageModule;
});